// const config = {
//     JWT_SECRET: process.env.JWT_SECRET || "b2ad9612ac739b0e0e13b8b4ad626a3a38507d8504b2abc72cd9e17af91e94bfd64f29faac6a176060256b2bf8b48b134cf8a84a9d72ac73d4aa6eef12417ce9",
//     EMAIL: process.env.EMAIL || "surendrawankhade@gmail.com", // testing email & password
//     PASSWORD: process.env.PASSWORD || "cyjepyhwchonjuii",
//     ATLAS_URI: process.env.ATLAS_URI || "mongodb+srv://abhaywankhade2004:9529370446@cluster0.kvkqvtb.mongodb.net/login?retryWrites=true&w=majority",
//     AWS: {
//         bucketName: "clinginvoice",
//         region: "ap-southeast-2",
//         accessKeyId: 'AKIA3ACAYLO7SQIXYFPJ',
//         secretAccessKey: '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',
//     }
// }

// export default config;
